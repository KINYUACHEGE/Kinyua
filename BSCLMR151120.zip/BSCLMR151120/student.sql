-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2021 at 10:37 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajax`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `FirstName` varchar(50) NOT NULL,
  `MiddleName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `DateofBirthday` date NOT NULL,
  `Citizenship` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `CountyofBirth` varchar(50) NOT NULL,
  `ID` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `FormalEducation` varchar(50) NOT NULL,
  `LevelofEducation` varchar(50) NOT NULL,
  `Specify` varchar(50) NOT NULL,
  `filename` varchar(50) NOT NULL,
  `Languanges` varchar(50) NOT NULL,
  `disability` varchar(50) NOT NULL,
  `nature` varchar(50) NOT NULL,
  `Religious` varchar(50) NOT NULL,
  `Affiliation` varchar(50) NOT NULL,
  `PostalAddress` varchar(50) NOT NULL,
  `Town` varchar(50) NOT NULL,
  `PostalCode` varchar(50) NOT NULL,
  `County` varchar(50) NOT NULL,
  `Telephone` varchar(50) NOT NULL,
  `Mobile` varchar(50) NOT NULL,
  `EmailAddress` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
