<?php


$host="localhost";
$username="root";
$password="";
$dbname="AJAX";



try{


$db=new PDO("mysql:host=$host;dbname=$dbname",$username,$dbname);


$db=setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

$QUERY="INSERT INTO Student(FirstName,MiddleName,LastName,DateofBirthday,Citizenship,country,CountyofBirth,ID,Gender,FormalEducation,LevelofEducation,Specify,filename,Languanges,disability,nature,Religious,Affiliation,PostalAddress,PostalCode,Town,County,Telephone,Mobile,EmailAddress)VALUES(':FirstName,:MiddleName,:LastName,:DateofBirthday,:Citizenship,:country,:CountyofBirth,:ID,:Gender,:FormalEducation,:LevelofEducation,:Specify,:filename,:Languanges,:disability,:nature,:Religious,:Affiliation,:PostalAddress,:PostalCode,:Town,:County,:Telephone,:Mobile,:EmailAddress')";

$stmt=$db->prepare($QUERY);
$stmt->bindParam('FirstName',$FirstName);
$stmt->bindParam('MiddleName',$MiddleName);
$stmt->bindParam('LastName',$LastName);
$stmt->bindParam('DateofBirthday',$DateofBirthday);
$stmt->bindParam('Citizenship',$Citizenship);
$stmt->bindParam('country',$country);
$stmt->bindParam('CountyofBirth',$CountyofBirth);
$stmt->bindParam('ID',$ID);
$stmt->bindParam('Gender',$Gender);
$stmt->bindParam('FormalEducation',$FormalEducation);
$stmt->bindParam('LevelofEducation',$LevelofEducation);
$stmt->bindParam('Specify',$Specify);
$stmt->bindParam('filename',$filename);
$stmt->bindParam('Languanges',$Languanges);
$stmt->bindParam('disability',$disability);
$stmt->bindParam('explain',$nature);
$stmt->bindParam('Religious',$Religious);
$stmt->bindParam('Affiliation',$Affiliation);
$stmt->bindParam('PostalAddress',$PostalAddress);
$stmt->bindParam('PostalCode',$PostalCode);
$stmt->bindParam('Town',$Town);
$stmt->bindParam('County',$County);
$stmt->bindParam('Telephone',$Telephone);
$stmt->bindParam('Mobile',$Mobile);
$stmt->bindParam('EmailAddress',$EmailAddress);

$FirstName=$_POST['FirstName'];
$MiddleName=$_POST['MiddleName'];
$LastName=$_POST['LastName'];
$DateofBirthday=$_POST['DateofBirthday'];
$Citizenship=$_POST['Citizenship'];
$country=$_POST['country'];
$CountyofBirth=$_POST['CountyofBirth'];
$ID=$_POST['ID'];
$Gender=$_POST['Gender'];
$FormalEducation=$_POST['FormalEducation'];
$LevelofEducation=$_POST['LevelofEducation'];
$Specify=$_POST['Specify'];
$filename=$_POST['filename'];
$Languanges=$_POST['Languanges'];
$disability=$_POST['disability'];
$nature=$_POST['nature'];
$Religious=$_POST['Religious'];
$Affiliation=$_POST['Affiliation'];
$PostalAddress=$_POST['PostalAddress'];
$PostalCode=$_POST['PostalCode'];
$Town=$_POST['Town'];
$County=$_POST['County'];
$Telephone=$_POST['Telephone'];
$Mobile=$_POST['Mobile'];
$EmailAddress=$_POST['EmailAddress'];

$stmt->execute();

echo "Inserted succesfully";



}catch(PDOException e){


    echo  "Connection failed" .$e->getMessage();
}
















?>